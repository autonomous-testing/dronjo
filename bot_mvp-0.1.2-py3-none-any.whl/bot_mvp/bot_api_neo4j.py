"Simple Neo4j api for bot"

from uuid import uuid1
import logging

from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable

from bot_mvp.config.bot_config import BotConfig


class BotApiNeo4j:
    "Main class for bot 2 neo4j api"

    def __init__(self, config: BotConfig):
        logging.getLogger(__name__)
        self.config = config
        try:
            scheme = config.neo4j_scheme
            host_name = config.neo4j_host_name
            port = config.neo4j_port
            user = config.neo4j_user
            password = config.neo4j_password
            uri = f"{scheme}://{host_name}:{port}"
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
            logging.debug("Connected to Neo4j.")
        except:
            logging.fatal("Neo4j connection error.")
            raise

    def __del__(self):
        self.driver.close()

    def find_node(self, node_uuid, node_type):
        "Find node by uuid"
        with self.driver.session() as session:
            result = session.read_transaction(self._find_node, node_uuid, node_type)
            return result

    @staticmethod
    def _find_node(transaction, node_uuid, node_type):
        query = "MATCH (n:" + node_type + ") WHERE n.uuid = $node_uuid RETURN n"
        result = transaction.run(query, node_uuid=node_uuid)
        # Hack until 5.0.0 of Neo4j is released
        records = [record for record in result]
        if len(records) > 0:
            founded_node = records[0]
            logging.debug("Node founded: %s", founded_node)
            return records[0]
        logging.debug("Node not founded: %s", node_uuid)
        return None

    def create_node(self, node_uuid, node_type):
        "Create node"
        with self.driver.session() as session:
            if self.find_node(node_uuid, node_type) is None:
                session.write_transaction(self._create_node, node_uuid, node_type)

    @staticmethod
    def _create_node(transaction, node_uuid, node_type):
        query = "CREATE (n: " + node_type + " { uuid: $node_uuid }) RETURN n"
        result = transaction.run(query, node_uuid=node_uuid)
        try:
            logging.debug("Creating node of type %s with uuid=%s", node_type, node_uuid)
            return result.single()
        except ServiceUnavailable as exception:
            logging.error("%s raised an error: \n %s", query, exception)
            raise

    def find_relationships(self, node_uuid1, node_uuid2, relationship_type="CLICK"):
        "Find relationship between two nodes, return None if there is no relationship."
        with self.driver.session() as session:
            result = session.read_transaction(
                self._find_relationships, node_uuid1, node_uuid2, relationship_type
            )
            return result

    @staticmethod
    def _find_relationships(transaction, node_uuid1, node_uuid2, relationship_type):
        query = (
            "MATCH p=(n1 {uuid: $node_uuid1})-[r: "
            + relationship_type
            + "]->(n2 {uuid: $node_uuid2}) RETURN p"
        )
        result = transaction.run(
            query,
            node_uuid1=node_uuid1,
            relationship_type=relationship_type,
            node_uuid2=node_uuid2,
        )
        return [record for record in result]

    def create_relationship(self, node_uuid1, node_uuid2, relationship_type, locator):
        "Create relationship between two nodes."
        with self.driver.session() as session:
            if not self.find_relationships(node_uuid1, node_uuid2, relationship_type):
                session.write_transaction(
                    self._create_relationship,
                    node_uuid1,
                    node_uuid2,
                    relationship_type,
                    locator,
                )

    @staticmethod
    def _create_relationship(
        transaction, node_uuid1, node_uuid2, relationship_type, locator
    ):
        query = (
            "MATCH (n1 {uuid: $node_uuid1}) MATCH (n2 {uuid: $node_uuid2}) CREATE (n1)-[r:"
            + relationship_type
            + ' {locator: "'
            + locator
            + '"}]->(n2) RETURN r'
        )
        transaction.run(query, node_uuid1=node_uuid1, node_uuid2=node_uuid2)

    def shortest_path(self, start, end):
        "Find shortest path between two nodes."
        with self.driver.session() as session:
            result = session.read_transaction(self._shortest_path, start, end)
        return result

    @staticmethod
    def _shortest_path(transaction, start, end):
        query = "MATCH (n1 {uuid: $start}),(n2 {uuid: $end}), path = allShortestPaths((n1)-[*..10]->(n2)) RETURN path"
        result = transaction.run(query, start=start, end=end)
        return [record["path"] for record in result]

    def prep_path(self, paths):
        "WIP Parse path to list of nodes and list of relationships."
        path = paths[0]
        nodes = [node.get("uuid") for node in path.nodes]
        relationships = [rel.get("locator") for rel in path.relationships]
        return nodes, relationships

    def is_locator_attached(self, node_uuid, locator):
        "Check if locator is attached to node."
        with self.driver.session() as session:
            result = session.read_transaction(
                self._is_locator_attached, node_uuid, locator
            )
        return result

    @staticmethod
    def _is_locator_attached(transaction, node_uuid, locator):
        # TODO Node -> project_name
        query = (
            'MATCH (n:Node { uuid: $node_uuid })-[r:CLICK {locator: "'
            + locator
            + '"}]->() RETURN r'
        )
        logging.debug("Query: %s", query)
        result = transaction.run(query, node_uuid=node_uuid)
        test = [record for record in result]
        if not test:
            return False
        return True

    def is_locator_attached_in_graph(self, locator):
        "Check if locator is attached at all."
        with self.driver.session() as session:
            result = session.read_transaction(
                self._is_locator_attached_in_graph,
                self.config.neo4j_project_name,
                locator,
            )
        return result

    @staticmethod
    def _is_locator_attached_in_graph(transaction, node_type, locator):
        query = (
            "MATCH (n:" + node_type + ')-[r {locator: "' + locator + '"}]-() RETURN r'
        )
        logging.debug("Query: %s", query)
        result = transaction.run(query)
        test = [record for record in result]
        if not test:
            return False
        return True

    def is_graph_empty(self):
        "Check if graph is empty."
        with self.driver.session() as session:
            result = session.read_transaction(self._is_graph_empty)
        return result

    @staticmethod
    def _is_graph_empty(transaction):
        query = "MATCH (n:Node) RETURN n LIMIT 1"
        result = transaction.run(query)
        test = [record for record in result]
        if not test:
            return True
        return False

    def update_graph(self, acceptable_states, current_position):
        "Update graph."
        node_type = self.config.neo4j_project_name
        for acceptable_state in acceptable_states:
            logging.debug(
                "Checking if locator %s goes from %s",
                acceptable_state,
                current_position,
            )
            if not self.is_locator_attached_in_graph(acceptable_state):
                new_uuid = uuid1().hex
                self.create_node(new_uuid, node_type)
                self.create_relationship(
                    current_position, new_uuid, "CLICK", acceptable_state
                )
                logging.debug(
                    "Adding new locator %s under uuid: %s at position %s",
                    acceptable_state,
                    new_uuid,
                    current_position,
                )

    def get_random_node(self):
        "Get random node"
        with self.driver.session() as session:
            result = session.read_transaction(
                self._get_random_node, self.config.neo4j_project_name
            )
        return result

    @staticmethod
    def _get_random_node(transaction, node_type):
        query = (
            "MATCH (u:"
            + node_type
            + ") WITH u, rand() AS number RETURN u ORDER BY number LIMIT 1"
        )
        result = transaction.run(query)
        nodes = [record for record in result]
        return nodes[0][0].get("uuid")
