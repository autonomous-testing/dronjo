"Simple VRT api for bot"

import logging

from visual_regression_tracker import Config as VrtConfig
from visual_regression_tracker import VisualRegressionTracker, TestRun

from bot_mvp.config.bot_config import BotConfig


class BotApiVrt:
    "Main class for bot 2 vrt api"

    def __init__(self, config: BotConfig):
        logging.getLogger(__name__)
        self.config = config
        try:
            vrt_config = VrtConfig(
                apiUrl=self.config.vrt_api_url,
                project=self.config.vrt_project_name,
                apiKey=self.config.vrt_api_key,
                ciBuildId=self.config.vrt_ci_build_id,
                branchName=self.config.vrt_branch_name,
                enableSoftAssert=True,
            )
            self.driver = VisualRegressionTracker(vrt_config)
            self.driver.start()
            logging.debug("Connected to VRT.")
        except:
            logging.fatal("VRT connection error.")
            raise

    def __del__(self):
        self.driver.stop()

    def track_screenshot(self, state_id, screenshot, ignore_areas: list = None):
        "Track screenshot"
        self.driver.track(
            TestRun(
                name=state_id,
                imageBase64=screenshot,
                ignoreAreas=ignore_areas,
                diffTollerancePercent=self.config.vrt_diff_tollerance,
            )
        )
