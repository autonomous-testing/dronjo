"""
Module: bot_mvp console runner.
"""

import asyncio
import sys

from bot_mvp.bot_mvp import BotMap


def run():
    """Default runner for bot_mvp."""
    bot_map = BotMap(sys.argv[1])
    asyncio.run(bot_map.run())
