"Simple Async Playwright api for bot"

import base64
import logging

import numpy as np
from cv2 import IMREAD_COLOR, TM_SQDIFF_NORMED, imdecode, matchTemplate, minMaxLoc
from playwright.async_api import async_playwright
from visual_regression_tracker import IgnoreArea

from bot_mvp.config.bot_config import BotConfig


class BotApiPlaywright:
    "Main class for bot 2 async playwright api"

    def __init__(self, config: BotConfig):
        logging.getLogger(__name__)
        self.config = config
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None

    async def init(self):
        "Init async playwright"
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=self.config.headless
        )
        self.context = await self.browser.new_context(
            viewport={"width": 1920, "height": 1080}
        )
        self.page = await self.context.new_page()
        await self.page.goto(self.config.url)
        await self._accept_cookies()

    async def stop(self):
        "Close async playwright"
        await self.browser.close()

    async def _accept_cookies(self):
        "Accept cookies"
        if self.config.cookies_selector is not None:
            await self.page.click(self.config.cookies_selector)
            logging.debug("Cookies accepted")

    async def collect_all_acceptable_states(self):
        "Collect all acceptable states"
        tag_selectors = self.config.tags
        acceptable_states = []
        for tag_selector in tag_selectors:
            elements = self.page.locator(tag_selector)
            n_elements = await elements.count()
            for i in range(n_elements):
                element = elements.nth(i)
                if await element.is_enabled() and await element.is_visible():
                    locator = await self._get_locator(element, tag_selector)
                    if locator is not None:
                        if await self.page.locator(locator).count() == 1:
                            acceptable_states.append(locator)
        return acceptable_states

    async def _get_locator(self, element, element_tag):
        "Get locator of the element."
        parent = element.locator("xpath=..")
        parent_class = await self._get_class_formatted(parent)
        element_text = await self._get_text_formatted(element)
        element_class = await self._get_class_formatted(
            element, element_tag=element_tag
        )
        locator = parent_class + " >> " + element_class
        if element_text is not None:
            locator += " >> text=" + element_text
        return locator

    @staticmethod
    async def _get_text_formatted(element):
        "Get formatted text of the element."
        raw_text = await element.inner_text()
        if raw_text == "":
            return None
        if len(raw_text.split()) == 1:
            return raw_text
        regex_text = raw_text  # "/" + ".*".join(raw_text.split()) + "/"
        return regex_text

    async def _get_class_formatted(self, element, element_tag="*"):
        "Get formatted class of the element."
        raw_class = await element.get_attribute("class")
        xpath = "xpath=//" + element_tag
        if raw_class is not None and raw_class != "":
            xpath += "[@class='" + raw_class + "']"
        return xpath

    def check_domain(self):
        "Check domain."
        current_url = self.page.url
        tested_url = self.config.url
        if current_url.startswith(tested_url):
            return True
        logging.debug("Bot went out of tested domain.")
        return False

    async def scroll_down(self, delta_y=1000):
        "Scroll down whole page, wait for loading and go back up."
        curr_height = await self.page.evaluate("(window.innerHeight + window.scrollY)")
        logging.debug("Current height: %s", curr_height)
        new_height = 0
        max_scroll_downs = 50
        n_scroll_downs = 0
        while (curr_height - new_height) != 0:
            n_scroll_downs += 1
            curr_height = new_height
            await self.page.mouse.wheel(0, delta_y)
            await self.page.wait_for_timeout(self.config.time_out / 5)
            logging.debug("Scrooling down...")
            new_height = await self.page.evaluate(
                "(window.innerHeight + window.scrollY)"
            )
            logging.debug("Current height: %s", new_height)
            if n_scroll_downs > max_scroll_downs:
                break
        for _ in range(n_scroll_downs + 1):
            await self.page.mouse.wheel(0, -delta_y)
        await self.page.wait_for_timeout(self.config.time_out / 5)

    async def check_for_ignored_locators(self):
        "Check for ignored locators"
        ignored_locators = self.config.ignored_areas_by_locator
        locator_images = []
        for locator in ignored_locators:
            element = self.page.locator(locator)
            if await element.is_visible():
                img_el_bytes = await element.screenshot()
                img_el_cv = imdecode(
                    np.frombuffer(img_el_bytes, dtype=np.uint8), flags=IMREAD_COLOR
                )
                locator_images.append(img_el_cv)
        return locator_images

    def get_ignored_areas(self, current_position, founded_locator_images, full_image):
        "Get ignored areas"
        ignore_areas = []
        full_img_cv = imdecode(
            np.frombuffer(full_image, dtype=np.uint8), flags=IMREAD_COLOR
        )
        for image in founded_locator_images:
            size_y, size_x = image.shape[:-1]
            res = matchTemplate(full_img_cv, image, TM_SQDIFF_NORMED)
            _, _, min_loc, _ = minMaxLoc(res)
            loc_x, loc_y = min_loc
            ignore_area = IgnoreArea(x=loc_x, y=loc_y, width=size_x, height=size_y)
            ignore_areas.append(ignore_area)
        if current_position in self.config.ignored_areas_by_coordinates.keys():
            ignore_areas.extend(
                self.config.ignored_areas_by_coordinates[current_position]
            )
        if "all" in self.config.ignored_areas_by_coordinates.keys():
            ignore_areas.extend(self.config.ignored_areas_by_coordinates["all"])
        return ignore_areas

    async def get_screenshot_and_ignore_areas(self, current_position):
        "Getter for screenshot and ignore_areas"
        img_bytes = await self.page.screenshot(full_page=True)
        logging.debug("Full page screenshot at %s", current_position)
        founded_locator_images = await self.check_for_ignored_locators()
        ignore_areas = []
        if len(founded_locator_images):
            ignore_areas = self.get_ignored_areas(
                current_position, founded_locator_images, img_bytes
            )
        img_b64 = base64.b64encode(img_bytes).decode("utf-8")
        return img_b64, ignore_areas
