"bot-mvp class"

import logging.config
import bot_mvp

from bot_mvp.bot_api_neo4j import BotApiNeo4j
from bot_mvp.bot_api_playwright import BotApiPlaywright
from bot_mvp.bot_api_vrt import BotApiVrt
from bot_mvp.config import logging_config
from bot_mvp.config.bot_config import load_yaml_config

logging.config.dictConfig(logging_config.config)


class BotMap:
    "BotMap class"

    def __init__(self, config_file):
        logging.getLogger(__name__)
        logging.info("Welcome to autonomous testing!")
        logging.info(f"Wopee (version {bot_mvp.__version__}) starting.")
        self.config = load_yaml_config(config_file)
        logging.debug(self.config)
        self.graph = BotApiNeo4j(self.config)
        self.vrt = BotApiVrt(self.config)
        self.playwright = BotApiPlaywright(self.config)
        self.start_position = self.config.url

    async def _first_run(self):
        current_position = self.start_position
        if (
            self.graph.find_node(current_position, self.config.neo4j_project_name)
            is None
        ):
            logging.info("Graph is not containing starting position")
            self.graph.create_node(current_position, self.config.neo4j_project_name)
            acceptable_states = await self.playwright.collect_all_acceptable_states()
            self.graph.update_graph(acceptable_states, current_position)

    async def run(self):
        "bot runner"

        await self.playwright.init()
        await self._first_run()

        for ith_action in range(0, self.config.number_of_actions):
            logging.info("action: %s", str(ith_action + 1))
            random_target = self.graph.get_random_node()
            # dirty hack
            while random_target == self.start_position:
                random_target = self.graph.get_random_node()
            logging.debug("random_target: %s", random_target)
            paths = self.graph.shortest_path(self.start_position, random_target)
            nodes, relationships = self.graph.prep_path(paths)
            await self.playwright.page.goto(self.config.url)
            logging.debug("Bot is at start: %s", self.config.url)
            current_position = self.start_position

            for i in range(1, len(nodes)):
                position = nodes[i]
                locator = relationships[i - 1]
                element = self.playwright.page.locator(locator)
                try:
                    await element.click(timeout=self.config.time_out)
                    logging.debug(
                        "Going from current_position %s to position %s via %s",
                        current_position,
                        position,
                        locator,
                    )
                except:  # pylint: disable=bare-except
                    logging.warning(
                        "Unreachable position %s at current_position %s by %s",
                        position,
                        current_position,
                        locator,
                    )
                    break
                current_position = position
                if not self.playwright.check_domain():
                    break
                acceptable_states = (
                    await self.playwright.collect_all_acceptable_states()
                )
                logging.debug("acceptable_states: %s", acceptable_states)
                await self.playwright.scroll_down()
                (
                    image64,
                    ignore_areas,
                ) = await self.playwright.get_screenshot_and_ignore_areas(
                    current_position
                )
                self.vrt.track_screenshot(current_position, image64)
                self.graph.update_graph(acceptable_states, position)
        await self.playwright.stop()
