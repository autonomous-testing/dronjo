"""
Configuration orchestraion for the BotMap.
"""

# pylint: disable=no-self-argument
# pylint: disable=no-self-use
# pylint: disable=missing-function-docstring


from typing import List
from uuid import uuid1

import yaml
from pydantic import BaseSettings, ValidationError, validator, Field


class BotConfig(BaseSettings):
    """
    Configuration for the bot-mvp.
    """

    vrt_project_name: str
    vrt_api_key: str = Field(..., env="VRT_API_KEY")
    vrt_api_url: str = "http://localhost:4200"
    vrt_ci_build_id: str = str(uuid1())
    vrt_branch_name: str = "master"
    vrt_diff_tollerance: int = 1
    neo4j_scheme: str = "neo4j"
    neo4j_host_name: str = "localhost"
    neo4j_port: int = 7687
    neo4j_user: str = "neo4j"
    neo4j_password: str = "test"
    neo4j_project_name: str
    url: str
    cookies_selector: str = None
    number_of_actions: int = 20
    headless: bool = True
    time_out: int = 2000
    tags: List[str] = ["a"]
    ignored_areas_by_locator: List[str] = []
    ignored_areas_by_coordinates: dict = {"all": []}

    @validator("neo4j_project_name")
    def neo4j_project_name_must_contain_space(cls, field):
        if " " in field:
            raise ValueError("must not contain a space")
        return field


def load_yaml_config(config_file_path: str) -> BotConfig:
    """
    Loads the configuration from a yaml file.
    """
    with open(config_file_path, "r", encoding="utf-8") as file:
        config = yaml.safe_load(file)
    try:
        bot_config = BotConfig(**config)
    except ValidationError as error:
        print(error.json())

    return bot_config
