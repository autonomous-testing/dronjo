"""
Log configuration for the bot_mvp.
"""

# pylint: disable=line-too-long
# pylint: disable=too-few-public-methods

import logging


class OnlyInfo(logging.Filter):
    "Class for logging filter to log only info level messages."

    def filter(self, record):
        "Logging filter to log only info level messages."
        return record.levelno == logging.INFO


config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "detailed": {
            "format": "[%(asctime)s.%(msecs)03d][%(levelname)-8s][%(filename)s.%(funcName)s:%(lineno)d]: %(message)s",
            "datefmt": "%Y %m %d %H:%M:%S",
        }
    },
    "filters": {"only_info": {"()": OnlyInfo}},
    "handlers": {
        "stdout": {
            "class": "logging.StreamHandler",
            "level": logging.INFO,
            "formatter": "detailed",
            "filters": ["only_info"],
        },
        "file_all": {
            "class": "logging.FileHandler",
            "filename": "bot.log",
            "mode": "w",
            "level": logging.DEBUG,
            "formatter": "detailed",
            "filters": [],
        },
        "file_errors": {
            "class": "logging.FileHandler",
            "filename": "bot.errors.log",
            "mode": "w",
            "level": logging.ERROR,
            "formatter": "detailed",
            "filters": [],
        },
    },
    "root": {"level": "NOTSET", "handlers": ["stdout", "file_all", "file_errors"]},
}
